const prompt = require('prompt-sync')();
const methods = require("./methods");
var fileName = 'data.txt';
console.log("Welcome to Good Match");
while(true){
console.log("please select a a gamemode: ");
console.log("1. Use local name data ");
console.log("2. input csv path for names file  ");
console.log("3. input your two of your own names  ");
console.log("4. Exit  ");
var choice = prompt('Your choice?');

if(choice==3){
  let name1= prompt("Enter first name 1: ");
  name1 = name1.replace(/[^A-Za-z]+/g, ' ');
  name1=name1.trim();
  let name2= prompt("Enter first name 2: ");
  name2 = name2.replace(/[^A-Za-z]+/g, ' ');
  name2=name2.trim();
  console.log(methods.driver(name1,name2));

}
else if (choice==2) {
  let entry= prompt("Enter csv file path: ");
  fileName=entry.toString();
  readFile(fileName);
  console.log("Check output.txt for results");
}
else if(choice==1){
  fileName='data.txt';
  readFile(fileName);
  console.log("Check output.txt for results");
}
else if (choice==4) {
  break;
}
else {
  console.log("Invalid entry please try again: ")
}
console.log("******************************************************");
}

function readFile(file){

  fileName = file;//window.prompt("welcome to Good Match, please enter the path of your cvs file or press 0 to continue");


  var fs = require('fs');
  var content = fs.readFileSync(fileName, 'utf8').toString();


  const myMap = new Map();
  var male= new Set();
  var female= new Set();
  content = content.replace(/[^A-Za-z]+/g, ' ');
  content=content.trim();
  while(true){
    const myArr = content.split(' ');
    if(myArr.length%2 != 0){
      console.log("Please specify gender for each name");
      break
    }


    for (var i = 0; i < myArr.length; i=i+2) {

      if(myArr[i+1]=="m"|myArr[i+1]=="M"){
        male.add(myArr[i]);
      }
      else if(myArr[i+1]=="f"|myArr[i+1]=="F"){
        female.add(myArr[i]);
      }
      else{
        console.log("Couldn't find gender for: "+ myArr[i]);
        break;
      }
    }


    let output="";
    for(let m of male.values()){

      for (let f of female.values()) {
        try {
          output = methods.driver(m.toString(),f.toString());
          myMap.set(output,parseInt(output.replace(/[^0-9]+/g, ' ')));
              }
        catch(err) {
          console.log("Could not find match percentage for: "+m+" and "+f);
              }


      }
    }
    let fileContent = '';
    const sortEntries = new Map([...myMap.entries()].sort());
    const mapSorted = new Map([...sortEntries.entries()].sort((a, b) => b[1] - a[1]));
    for (let out of mapSorted.keys()) {
        fileContent+=out+"\n";
    }

    fs.writeFileSync('output.txt', fileContent);
    break;
  }

}
console.log("Program has ended. ")
