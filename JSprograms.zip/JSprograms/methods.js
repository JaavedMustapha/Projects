
function numCal(s1) {
let s= s1
let newS="";
while(s.length>2){
  newS="";

  let first=s.substring(0,(s.length/2))
  let second=s.substring((s.length/2),s.length)

  if( first.length > second.length){
    second+= "0";
  }
  else if (first.length < second.length) {
    first+="0";
  }
  second= second.split("").reverse().join("");
  for (var i = 0; i < first.length; i++) {
    var a = parseInt(first.charAt(i));
    var b = parseInt(second.charAt(i));
    newS+= (a+b).toString();

  }
  s=newS;

}
  return s;
}

function nameMatch(n1,n2){
  let name1= n1;
  let name2= n2;
  let s= n1+"matches"+n2
  var counter=0;
  let match=""
  s=s.trim()
  let checked=""
  for(var i=0;i<s.length;i++){
    let c= s[i];
    if(checked.indexOf(s[i])==-1){
      for(var j= i ; j<s.length; j++){
          if(s[i]==s[j]){
            counter++
          }
      }
    checked+=s[i];
    }
    if(counter!=0){
      match+= counter.toString();
  }
    counter=0;
  }

  return match;
}
function isAlpha(s) {
  var c;
  let str=s.toLowerCase();
  for (var i = 0 ; i < str.length; i++) {
    c = str.charCodeAt(i);
    if (97 > c || c > 122) {
      return false;
    }
  }
  return true;
}
function driver(str1,str2){
  let output;
  let str= str1+str2;
  if(!(isAlpha(str))){
    return "invalid names entered";
  }
  str1= str1.toLowerCase();
  str2= str2.toLowerCase();
  var perc= parseInt(numCal(nameMatch(str1,str2)));
  if(perc>=80){
    output= str1+" "+"matches"+" "+str2+" "+perc.toString()+"%"+", good match.";
  }
  else{
    output= str1+" "+"matches"+" "+str2+" "+perc.toString()+"%";
  }


  return output;
}

module.exports = { driver };
